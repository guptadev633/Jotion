export default {
    providers: [
        {
            domain: "https://notable-squid-18.clerk.accounts.dev",
            applicationID: "convex",
        }
    ]
}